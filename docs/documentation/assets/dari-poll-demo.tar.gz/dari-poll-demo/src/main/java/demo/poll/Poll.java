package demo.poll;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.psddev.dari.db.Database;
import com.psddev.dari.db.Grouping;
import com.psddev.dari.db.Query;
import com.psddev.dari.db.Record;
import com.psddev.dari.util.ObjectUtils;

public class Poll extends Record {

    @Required @Indexed(unique = true)
    private String question;

    protected Poll() {
    }

    // --- getters / setters

    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }

    // --- helper methods ---

    /** Creates a new Poll object along with its corresponding answers and
     *  saves them. */
    public static Poll createPoll(String question, List<String> answers) {

        // We use transactions here so that if an answer fails to save, the
        // poll will get rolled back and also not get saved.
        Database db = Database.Static.getDefault();
        try {
            db.beginWrites();

            Poll poll = new Poll();
            poll.setQuestion(question);
            poll.save();

            if (answers != null) for (String answerText : answers) {
                Answer answer = new Answer();
                answer.setPoll(poll);
                answer.setAnswer(answerText);
                answer.save();
            }

            db.commitWrites();

            return poll;

        } finally {
            db.endWrites();
        }
    }

    /** Helper method that queries for the answers to the current poll. */
    public List<Answer> getAnswers() {
        return Query.from(Answer.class).where("poll = ?", this).selectAll();
    }

    /** Submits a user's answer to the poll and returns a saved response. */
    public UserResponse submit(String userName, UUID answerId) throws IllegalArgumentException {

        // Find the PollAnswer object for the specified answerId
        Answer answer = Query.from(Answer.class)
                .where("id = ?", answerId)
                .and("poll = ?", this) // to make sure the answer belongs to the current poll
                .first();

        User user = Query.findUnique(User.class, "userName", userName);
        // if no user with that name then create a new one on the fly ONLY if
        // the name isn't blank
        if (user == null) {

            if (ObjectUtils.isBlank(userName)) {
                // set blank names to null and let the database capture the exception
                userName = null;
            }

            user = new User();
            user.setUserName(userName);
            user.save();
        }

        if (hasUserVoted(user)) {
            throw new IllegalArgumentException("User already submitted an answer to this poll!");
        }

        UserResponse response = null;
        response = new UserResponse();
        response.setUser(user);
        response.setAnswer(answer);
        response.save();

        return response;
    }

    /** Returns true if this user has not yet voted, false otherwise. */
    public boolean hasUserVoted(User user) {
        if (user == null) {
            return false;
        }
        return Query.from(UserResponse.class)
                .where("answer/poll = ?", this)
                .and("user = ?", user)
                .count() != 0;
    }

    /** Gets the poll results as a mapping of answer to the number of responses
     *  with that answer. */
    public Map<Answer, Long> getPollResults() {

        Map<Answer, Long> pollResults = new HashMap<Answer, Long>();

        // Queries for responses that have answers to this poll
        Query<UserResponse> responseQuery = Query.from(UserResponse.class)
                .where("answer/poll = ?", this);

        // Group the responses by their answers to get counts for each
        for (Grouping<UserResponse> grouping : responseQuery.groupBy("answer")) {

            // Returns the list of fields that we grouped by. In this case just one, "answer".
            List<Object> keys = grouping.getKeys();
            Object key0 = keys.get(0);

            if (key0 instanceof Answer) {
                Answer answer = (Answer) key0;
                long answerCount = grouping.getCount(); // the number of responses with this answer

                pollResults.put(answer, answerCount);
            }
        }

        return pollResults;
    }

    /** Returns the total number of responses to this poll. */
    public long getPollResponseCount() {
        // Queries for responses that have answers to the specified poll
        return Query.from(UserResponse.class)
                .where("answer/poll = ?", this)
                .count();
    }
}

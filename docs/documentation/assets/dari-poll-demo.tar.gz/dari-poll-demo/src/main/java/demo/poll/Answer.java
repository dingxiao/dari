package demo.poll;

import com.psddev.dari.db.Record;

/** A possible answer to a poll */
public class Answer extends Record {

    @Required @Indexed private Poll poll;
    @Required @Indexed private String answer;

    public Poll getPoll() {
        return poll;
    }
    public void setPoll(Poll poll) {
        this.poll = poll;
    }
    public String getAnswer() {
        return answer;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
}

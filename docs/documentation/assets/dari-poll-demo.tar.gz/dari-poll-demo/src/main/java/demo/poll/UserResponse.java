package demo.poll;

import com.psddev.dari.db.Record;

/** A user's answer to a poll */
public class UserResponse extends Record {

    @Required @Indexed private User user;
    @Required @Indexed private Answer answer;

    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
    public Answer getAnswer() {
        return answer;
    }
    public void setAnswer(Answer answer) {
        this.answer = answer;
    }
}
